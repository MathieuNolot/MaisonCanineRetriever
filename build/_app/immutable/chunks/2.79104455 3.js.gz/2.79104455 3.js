import{default as t}from"../entry/_page.svelte.c9a0e36b.js";export{t as component};
