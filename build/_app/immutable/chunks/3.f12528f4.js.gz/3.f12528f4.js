import{default as t}from"../entry/boutique-page.svelte.6893c39a.js";export{t as component};
