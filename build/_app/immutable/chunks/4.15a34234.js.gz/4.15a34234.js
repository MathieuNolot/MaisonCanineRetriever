import{default as t}from"../entry/panier-page.svelte.0b9dfd1d.js";export{t as component};
