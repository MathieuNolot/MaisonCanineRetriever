import{default as t}from"../entry/_layout.svelte.6d832e1a.js";export{t as component};
