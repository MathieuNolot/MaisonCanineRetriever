import{default as t}from"../entry/error.svelte.99d05ba3.js";export{t as component};
